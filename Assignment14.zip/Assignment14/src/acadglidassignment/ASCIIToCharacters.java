package acadglidassignment;

import java.io.IOException;

public class ASCIIToCharacters {

	public static void main(String [] args) throws IOException
	{
		try
		{
			for(int i=65; i<=90; i++)
			{
				System.out.println("\n"+ i +"-"+(char)i);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Exception in conversion" + ex.getMessage());
		}
	}
}
